# SVBSTRATE

## Base-level SCSS framework for OOCSS projects.

### [Demo](http://svbstrate.io)

Created with love and curiosity by [@estrattonbailey](http://twitter.com/estrattonbailey).
